var express = require('express');
var app = express();
var router = require('./routes/route');

var bodyParser = require('body-parser');
var cors = require('cors');

var errorLogger = require('./public/javascript/ErrorLogger');
var requestLogger = require('./public/javascript/RequestLogger');

//app.use(cors());
app.use(bodyParser.json());

app.use(requestLogger);
app.use('/',router);
app.use(errorLogger);

app.listen(3000);
console.log('Server Started at port 3000!');

