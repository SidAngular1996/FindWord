var express = require('express')
var router = express.Router()
var wordServer = require('../public/javascript/wordServer')
const fs = require('fs')
const path = require('path')


router.use(express.static('public'));

router.get('/', function (req, res) {
  let url = path.join(__dirname, '../public/html/homepage.html')
  if (fs.existsSync(url)) res.sendFile(url)
  else {
    res.end()
  }
})

router.get('/addWord', function (req, res) {
  let suggestHtml = `<!DOCTYPE html>
      <html>
      <head>
        <script src="addWord.js" ></script>
        <script  src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        
        <script  src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>   
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">       
        <link rel="stylesheet" href="../stylesheet/style.css">
        
              <title>Suggest a Word</title>
      </head>
      <body class="forBody">
        <header>
                <nav class="navbar navbar-expand-md bg-info navbar-dark ">
                    <a class="navbar-brand" href="http://localhost:3000/">Wurdan!</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item"><a class="nav-link" href="http://localhost:3000/addWord" style="color:white;" >Suggest a Word</a></li>
                        </ul>
                    </div>
                </nav>
            </header>
          <br>
          <div class="container-fluid">
              <div class="row">
                  <div class="col-md-4 offset-4 bordering">
                          <h4 class="text-center">Do you wish to add a word?</h4><br>
                            <form onsubmit="saveWord(event)">
                                <div class="form-group">
                                    <label for="addWord"><b>Word to be added</b></label>
                                    <input type="text" id="addWord" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="addMeaning"><b>Its meaning</b></label>
                                    <textarea id="addMeaning" class="form-control" required></textarea>
                                </div>
                                <div class="form-group text-center">
                                    <button type="submit" class="btn btn-info">Add word to Dictionary</button>
                                </div>
                                <div class="form-group text-center">
                                    <h6 id="msg"></h6>
                                </div>
                            </form>
                  </div>
              </div>
          </div>
      </body>
      </html>`
  res.set('Content-Type', 'text/html')
  res.send(suggestHtml)
})

router.get('/search/:word', function (req, res) {
  wordSearched = req.params.word
  return wordServer
    .findWord(wordSearched)
    .then(function (meaning) {
      res.json({ message: meaning })
    })
    .catch(function (err) {
      res.json({ message: 'Oops! Word does not exist in the dictionary.' })
    })
})

router.post('/add', function (req, res) {
  let input = req.body
  return wordServer
    .addWord(input.word, input.meaning)
    .then(function (word) {
      res.json({ message: 'Successfully added ' + word + ' to dictionary' })
    })
    .catch(function (err) {
      res.json({ message: 'Word could not be added!' })
    })
})

router.get(/js/, (req, res) => {
    try{
        res.set('Content-Type', 'text/javascript')
        console.log("Check",req.url.toString());
      
        var url=  path.join(__dirname, '../', req.url)
        console.log("URL is ",url);
        if (!req.url.toString().includes('wurdanService')) {
          console.log(req.url)
          url = path.join(__dirname, '../public/javascript', req.url)
        }
        if (fs.existsSync(url)) {
            console.log("Sending file ",url)
          res.sendFile(url)
        } else {
          res.end()
        }
    } catch(e) {
        console.error("Error",e)
    }
 
})

router.get(/html/, (req, res) => {
  let url = path.join(__dirname, '../public/html', req.url)
  res.set('Content-Type', 'text/html')
  if (fs.existsSync(url)) res.sendFile(url)
  else {
    res.end()
  }
})

router.get(/css/, (req, res) => {
  res.set('Content-Type', 'text/css')
  let url = path.join(__dirname, '../public/stylesheet', req.url)
  if (fs.existsSync(url)) res.sendFile(url)
  else {
    res.end()
  }
})

module.exports = router
