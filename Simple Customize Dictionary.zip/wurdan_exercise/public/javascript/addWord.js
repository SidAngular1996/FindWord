function saveWord(event) {

    var word = document.getElementById("addWord").value;
    var meaning = document.getElementById("addMeaning").value;
    fetch('http://localhost:3000/add', {
        method: "post",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },

        body: JSON.stringify({
            word: word,
            meaning: meaning
        })
    }).then(function (response) {
        return response.json();
    }).then(function (json) {
        document.getElementById("msg").innerHTML = json["message"];
    });
    event.preventDefault();
};