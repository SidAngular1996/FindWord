function search () {
  document.getElementById('meaning').style.visibility = 'visible';

  let input = document.getElementById('sInput').value;
  let searchedWord = input.toLowerCase();

  fetch('http://localhost:3000/search/' + searchedWord)
    .then(res => res.json())
    .then(json => {
      document.getElementById('defn').innerHTML = json['message']
    })
    .catch(err =>
      console.log(
        (document.getElementById('meaning').innerHTML =
          'Some error!Please try again')
      )
    )
}
