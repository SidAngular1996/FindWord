var MongoClient = require('mongodb');        
var connection =  MongoClient.connect('mongodb://localhost:27017/DictionaryApp', { useNewUrlParser: true });

wordServer = {}
wordServer.findWord = function(wordSearched){
    return connection.then(function(mongoClient){
        var dataBase = mongoClient.db();
        var collection = dataBase.collection('wurdan');
        return collection.findOne({word:wordSearched})
    }).then(function(result){
        if(result){
            console.log("here it cpmes...");
            
            return result.meaning
        } else {
            throw new Error("Oops! Word does not exist in the dictionary.")
        }
    })
};

wordServer.findRandomWord = function(){
    return connection.then(function(mongoClient){
        var dataBase = mongoClient.db();
        var collection = dataBase.collection('wurdan');

        return collection.aggregate([{ $sample: { size: 1 } }]).toArray()
        .then(function(result){
            return result[0]
        })
    });
}

wordServer.addWord = function(word,meaning){
    return connection.then(function(mongoClient) {
	    var dataBase = mongoClient.db();
        var collection = dataBase.collection('wurdan');

        let newWord = word.toLowerCase();
        let newMeaning = meaning.toLowerCase();

    return collection.insertOne({word:newWord,meaning:newMeaning}).then(function(result) {
        if(result.insertedCount>=1) {
            return word;
        } else {
            throw new Error('Sorry! Could not add the word')
        }
        
    });
  });
}

module.exports = wordServer;